﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FantasyFooty
{
    class Player
    {
        public String Webname { get; set; }
        public String Teamcode { get; set; }
        public String Status { get; set; }
        public String PhotoNum { get; set; }
        public String FirstName { get; set; }
        public String SecondName { get; set; }

        public Player(String name) {

            Webname = name;
        }
        
    }
}
