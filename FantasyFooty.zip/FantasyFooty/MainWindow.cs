﻿using System;
using System.IO;
using System.Net;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using BusinessLogic;




namespace FantasyFooty
{
    public partial class MainWindow : Form
    {
        List<Player> PlayerList = new List<Player>();
        string noPlayerImage = @"C:\Home\dropbox\fantasyfootball\Photos\Photo-Missing.png";

        public MainWindow()
        {
            InitializeComponent();
            BackendData.Update_Data();
            lblCurrent_Week.Text = "Game Week: " + BackendData.fantasyPlayer.Game_Week;
            lblPlayerCount.Text = BackendData.numberOfCurrentPlayer.ToString() + " Of " + BackendData.numberOfPlayers.ToString();
            string playerImage = @"C:\Home\dropbox\fantasyfootball\Photos\" + BackendData.get_Current_Player_Code() + ".png";
            PicturePlayer.Image =  Image.FromFile(playerImage);
            Update_Screen();
        }

        private void downloafPhotosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackendData.Download_Photos();
        }

        private void getJsonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackendData.Update_Data();
            //dataGridView1.DataSource = BackendData.fantasyPlayer.Element;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MainWindow_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            
        }

        private void MainWindow_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    
                    break;
                case Keys.Right:
                     break;
                case Keys.Up:
                    
                    break;
                case Keys.Down:
                    BackendData.increment_Player();
                    string playerImage = @"C:\Home\dropbox\fantasyfootball\Photos\" + BackendData.get_Current_Player_Code() + ".png";
                    PicturePlayer.Image = Image.FromFile(playerImage);

                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BackendData.increment_Player();
            Update_Screen();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BackendData.decrement_Player();
            Update_Screen();
        }

        private void Update_Screen()
        {
            Element currentPlayer = BackendData.get_Current_Player();
            string playerImage = @"C:\Home\dropbox\fantasyfootball\Photos\" + BackendData.get_Current_Player_Code() + ".png";
            try
            {
                PicturePlayer.Image = Image.FromFile(playerImage);
            }
            catch (Exception imageException)
            {
                PicturePlayer.Image = Image.FromFile(noPlayerImage);
            };

            lblPlayerCount.Text = BackendData.numberOfCurrentPlayer.ToString() + " Of " + BackendData.numberOfPlayers.ToString();

            var temp = Encoding.UTF8.GetBytes(currentPlayer.FirstName.ToString());
            lblFirstname.Text = (currentPlayer.FirstName);
            lblSecondName.Text = currentPlayer.SecondName;
            lblTeam.Text = BackendData.Get_Team_Name();
            lblTotalPoints.Text = "Total Points: " + currentPlayer.TotalPoints;
            if (currentPlayer.TotalPoints > 0)
            { lblAverageMinutes.Text = "Avg. Minutes : " + (currentPlayer.Minutes / Convert.ToDecimal(BackendData.Get_Games_Played())).ToString("0");            }
            else
            {  lblAverageMinutes.Text = "Avg. minutes : 0";  }
            lblPosition.Text = BackendData.Get_Player_Position();
            lblValue.Text = "Value: " + (currentPlayer.NowCost);
            lblPPG.Text = "Points Per Game: " + currentPlayer.PointsPerGame.ToString();

            DateTimeOffset? date1 = (currentPlayer.NewsAdded);
            lblChanceOfPlaying.Text = (String.Format("{0:dd/MMM/yyyy}",date1) + " - "  + currentPlayer.News) ;
            

            lblPPPM.Text = "PPPM : " + ((BackendData.Calculate_PPPM()).ToString("0.##"));
            if (currentPlayer.TotalPoints > 0)
            { lblGamesPlayed.Text = "No Of Games: " + BackendData.Get_Games_Played().ToString("0");
            }
            else
            { lblGamesPlayed.Text = "No Of Games: N/A"; }

            lblPPW.Text = "Points Per Week: " + ((currentPlayer.TotalPoints) / Convert.ToDecimal(BackendData.fantasyPlayer.Game_Week)).ToString("0.#");
            //dgvPlayerStats.Columns[RC].
        }       
        

        
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text != "")
            {
                //get the searched for player
                BackendData.get_player_search(txtSearch.Text);
                Update_Screen();
            }    
           
        }

        
        

        private void cmbSelectFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            BackendData.filter_Players(cmbSelectFilter.Text);
            Update_Screen();
        }

        private void cmbSelectFilter_SelectedValueChanged(object sender, EventArgs e)
        {
            BackendData.filter_Players(cmbSelectFilter.Text);
            Update_Screen();
        }
    }
}
