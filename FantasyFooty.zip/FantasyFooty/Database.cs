﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FantasyFooty
{
    class BackendData
    {
        //public List<Player> PlayerList = new List<Player>();
        public object fantasyPlayer;


        public void get_Website_data()
        { 
        // This servicepointmanager is added to avoid SSL error when accessing this site.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            WebClient client = new WebClient();
            try
            {
                using (client)
                {
                    //connect to the Fantasy Football JSON file
                    var json = client.DownloadString("https://fantasy.premierleague.com/drf/bootstrap-static");

                    //var fantasyPlayer = FantasyPlayer.FromJson(json);
                    fantasyPlayer = FantasyPlayer.FromJson(json);


                    //Create a reader to parse the json file and create/update the players database
                    //JsonTextReader reader = new JsonTextReader(new StringReader(json));

                    //this text file is temproray for readiing the output of the reader routine
                    //using (System.IO.StreamWriter file =
                    //         new System.IO.StreamWriter(@"C:\Home\dropbox\fantasyfootball\JSON.txt"))

                    //lets parse the json file and do the work up updating/creating the player database
                    /* while (reader.Read())
                     {
                         if (reader.Value != null)
                         {
                             Console.WriteLine("Token: {0}, Value: {1}", reader.TokenType, reader.Value);

                             // For every web_name create a player record
                             if (reader.Value.ToString() == @"web_name")
                             {
                                 reader.Read();
                                 file.WriteLine("Token: {0}, Value: {1}", reader.TokenType, reader.Value);
                                 Player newPlayer = new Player(reader.Value.ToString());
                                     reader.Read();
                                     reader.Read();
                                     newPlayer.Teamcode = reader.Value.ToString();
                                     reader.Read();
                                     reader.Read();
                                     newPlayer.Status = reader.Value.ToString();
                                     reader.Read();
                                     reader.Read();
                                     newPlayer.PhotoNum = reader.Value.ToString();
                                     reader.Read();
                                     reader.Read();
                                     newPlayer.FirstName = reader.Value.ToString();
                                     reader.Read();
                                     reader.Read();
                                     newPlayer.SecondName = reader.Value.ToString();
                                     PlayerList.Add(newPlayer);



                                 }
                             }
                             else
                             {
                                 Console.WriteLine("Token: {0}", reader.TokenType);
                                 //file.WriteLine("Token: {0}", reader.TokenType);
                             }*/

                    //dataGridView1.DataSource = fantasyPlayer.Element;
                            
                        

                    

                }

                //dataGridView1.DataSource = FantasyPlayer.                           
            }
            catch (Exception e) { };



        }

    }
}
