﻿namespace FantasyFooty
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblAverageMinutes = new System.Windows.Forms.Label();
            this.lblPPW = new System.Windows.Forms.Label();
            this.lblGamesPlayed = new System.Windows.Forms.Label();
            this.lblValue = new System.Windows.Forms.Label();
            this.lblPPPM = new System.Windows.Forms.Label();
            this.lblChanceOfPlaying = new System.Windows.Forms.Label();
            this.lblPPG = new System.Windows.Forms.Label();
            this.lblTotalPoints = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblTeam = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.PicturePlayer = new System.Windows.Forms.PictureBox();
            this.lblSecondName = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblCurrent_Week = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getJsonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.downloafPhotosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewRAWDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.functionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblPlayerCount = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cmbSelectFilter = new System.Windows.Forms.ComboBox();
            this.dgvPlayerStats = new System.Windows.Forms.DataGridView();
            this.RC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicturePlayer)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlayerStats)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 52);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1247, 651);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.dgvPlayerStats);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.lblAverageMinutes);
            this.tabPage1.Controls.Add(this.lblPPW);
            this.tabPage1.Controls.Add(this.lblGamesPlayed);
            this.tabPage1.Controls.Add(this.lblValue);
            this.tabPage1.Controls.Add(this.lblPPPM);
            this.tabPage1.Controls.Add(this.lblChanceOfPlaying);
            this.tabPage1.Controls.Add(this.lblPPG);
            this.tabPage1.Controls.Add(this.lblTotalPoints);
            this.tabPage1.Controls.Add(this.lblPosition);
            this.tabPage1.Controls.Add(this.lblTeam);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.PicturePlayer);
            this.tabPage1.Controls.Add(this.lblSecondName);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage1.Size = new System.Drawing.Size(1239, 615);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Player Details";
            // 
            // groupBox3
            // 
            this.groupBox3.Location = new System.Drawing.Point(929, 6);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(283, 306);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Average Stats By Position";
            // 
            // lblAverageMinutes
            // 
            this.lblAverageMinutes.AutoSize = true;
            this.lblAverageMinutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAverageMinutes.Location = new System.Drawing.Point(533, 96);
            this.lblAverageMinutes.Name = "lblAverageMinutes";
            this.lblAverageMinutes.Size = new System.Drawing.Size(217, 31);
            this.lblAverageMinutes.TabIndex = 13;
            this.lblAverageMinutes.Text = "Average Minutes";
            // 
            // lblPPW
            // 
            this.lblPPW.AutoSize = true;
            this.lblPPW.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPPW.Location = new System.Drawing.Point(534, 234);
            this.lblPPW.Name = "lblPPW";
            this.lblPPW.Size = new System.Drawing.Size(75, 31);
            this.lblPPW.TabIndex = 12;
            this.lblPPW.Text = "PPW";
            // 
            // lblGamesPlayed
            // 
            this.lblGamesPlayed.AutoSize = true;
            this.lblGamesPlayed.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGamesPlayed.Location = new System.Drawing.Point(536, 64);
            this.lblGamesPlayed.Name = "lblGamesPlayed";
            this.lblGamesPlayed.Size = new System.Drawing.Size(191, 31);
            this.lblGamesPlayed.TabIndex = 11;
            this.lblGamesPlayed.Text = "Games Played";
            
            // 
            // lblValue
            // 
            this.lblValue.AutoSize = true;
            this.lblValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue.Location = new System.Drawing.Point(255, 208);
            this.lblValue.Name = "lblValue";
            this.lblValue.Size = new System.Drawing.Size(83, 31);
            this.lblValue.TabIndex = 10;
            this.lblValue.Text = "Value";
            // 
            // lblPPPM
            // 
            this.lblPPPM.AutoSize = true;
            this.lblPPPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPPPM.Location = new System.Drawing.Point(533, 266);
            this.lblPPPM.Name = "lblPPPM";
            this.lblPPPM.Size = new System.Drawing.Size(90, 31);
            this.lblPPPM.TabIndex = 9;
            this.lblPPPM.Text = "PPPM";
            // 
            // lblChanceOfPlaying
            // 
            this.lblChanceOfPlaying.AutoSize = true;
            this.lblChanceOfPlaying.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChanceOfPlaying.Location = new System.Drawing.Point(5, 323);
            this.lblChanceOfPlaying.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblChanceOfPlaying.Name = "lblChanceOfPlaying";
            this.lblChanceOfPlaying.Size = new System.Drawing.Size(166, 24);
            this.lblChanceOfPlaying.TabIndex = 5;
            this.lblChanceOfPlaying.Text = "Chance Of Playing";
            // 
            // lblPPG
            // 
            this.lblPPG.AutoSize = true;
            this.lblPPG.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPPG.Location = new System.Drawing.Point(533, 129);
            this.lblPPG.Name = "lblPPG";
            this.lblPPG.Size = new System.Drawing.Size(71, 31);
            this.lblPPG.TabIndex = 8;
            this.lblPPG.Text = "PPG";
            // 
            // lblTotalPoints
            // 
            this.lblTotalPoints.AutoSize = true;
            this.lblTotalPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPoints.Location = new System.Drawing.Point(528, 22);
            this.lblTotalPoints.Name = "lblTotalPoints";
            this.lblTotalPoints.Size = new System.Drawing.Size(232, 46);
            this.lblTotalPoints.TabIndex = 7;
            this.lblTotalPoints.Text = "Total Points";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosition.Location = new System.Drawing.Point(255, 100);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(111, 31);
            this.lblPosition.TabIndex = 6;
            this.lblPosition.Text = "Position";
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam.Location = new System.Drawing.Point(255, 158);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(83, 31);
            this.lblTeam.TabIndex = 5;
            this.lblTeam.Text = "Team";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(853, 524);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 62);
            this.button2.TabIndex = 3;
            this.button2.Text = "Previous";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1068, 524);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 62);
            this.button1.TabIndex = 2;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PicturePlayer
            // 
            this.PicturePlayer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PicturePlayer.Location = new System.Drawing.Point(6, 6);
            this.PicturePlayer.Name = "PicturePlayer";
            this.PicturePlayer.Size = new System.Drawing.Size(244, 306);
            this.PicturePlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PicturePlayer.TabIndex = 1;
            this.PicturePlayer.TabStop = false;
            // 
            // lblSecondName
            // 
            this.lblSecondName.AutoSize = true;
            this.lblSecondName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondName.Location = new System.Drawing.Point(255, 54);
            this.lblSecondName.Name = "lblSecondName";
            this.lblSecondName.Size = new System.Drawing.Size(178, 31);
            this.lblSecondName.TabIndex = 0;
            this.lblSecondName.Text = "SecondName";
            this.lblSecondName.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblFirstname);
            this.groupBox1.Location = new System.Drawing.Point(254, 6);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(244, 306);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Player";
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstname.Location = new System.Drawing.Point(2, 16);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(140, 31);
            this.lblFirstname.TabIndex = 4;
            this.lblFirstname.Text = "FirstName";
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(525, 6);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(374, 306);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Stats";
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage2.Size = new System.Drawing.Size(1239, 615);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Player History";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblCurrent_Week
            // 
            this.lblCurrent_Week.AutoSize = true;
            this.lblCurrent_Week.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrent_Week.Location = new System.Drawing.Point(476, 9);
            this.lblCurrent_Week.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCurrent_Week.Name = "lblCurrent_Week";
            this.lblCurrent_Week.Size = new System.Drawing.Size(166, 29);
            this.lblCurrent_Week.TabIndex = 2;
            this.lblCurrent_Week.Text = "Current Week:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.functionsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1267, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.getJsonToolStripMenuItem,
            this.downloafPhotosToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // getJsonToolStripMenuItem
            // 
            this.getJsonToolStripMenuItem.Name = "getJsonToolStripMenuItem";
            this.getJsonToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.getJsonToolStripMenuItem.Text = "Get Latest Player Update";
            this.getJsonToolStripMenuItem.Click += new System.EventHandler(this.getJsonToolStripMenuItem_Click);
            // 
            // downloafPhotosToolStripMenuItem
            // 
            this.downloafPhotosToolStripMenuItem.Name = "downloafPhotosToolStripMenuItem";
            this.downloafPhotosToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.downloafPhotosToolStripMenuItem.Text = "Update Photos";
            this.downloafPhotosToolStripMenuItem.Click += new System.EventHandler(this.downloafPhotosToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewRAWDataToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // viewRAWDataToolStripMenuItem
            // 
            this.viewRAWDataToolStripMenuItem.Name = "viewRAWDataToolStripMenuItem";
            this.viewRAWDataToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.viewRAWDataToolStripMenuItem.Text = "View RAW Data";
            // 
            // functionsToolStripMenuItem
            // 
            this.functionsToolStripMenuItem.Name = "functionsToolStripMenuItem";
            this.functionsToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.functionsToolStripMenuItem.Text = "Functions";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // lblPlayerCount
            // 
            this.lblPlayerCount.AutoSize = true;
            this.lblPlayerCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerCount.Location = new System.Drawing.Point(13, 28);
            this.lblPlayerCount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPlayerCount.Name = "lblPlayerCount";
            this.lblPlayerCount.Size = new System.Drawing.Size(87, 20);
            this.lblPlayerCount.TabIndex = 4;
            this.lblPlayerCount.Text = "Player 1 of ";
            this.lblPlayerCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(978, 18);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 20);
            this.txtSearch.TabIndex = 6;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(1084, 7);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(123, 39);
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cmbSelectFilter
            // 
            this.cmbSelectFilter.FormattingEnabled = true;
            this.cmbSelectFilter.Items.AddRange(new object[] {
            "All",
            "DreamTeam",
            "GoalKeeper",
            "Defender",
            "Midfielder",
            "Forward",
            "Arsenal",
            "Chelsea",
            "Liverpool"});
            this.cmbSelectFilter.Location = new System.Drawing.Point(763, 18);
            this.cmbSelectFilter.Name = "cmbSelectFilter";
            this.cmbSelectFilter.Size = new System.Drawing.Size(132, 21);
            this.cmbSelectFilter.TabIndex = 8;
            this.cmbSelectFilter.SelectedIndexChanged += new System.EventHandler(this.btnSearch_Click);
            this.cmbSelectFilter.SelectedValueChanged += new System.EventHandler(this.cmbSelectFilter_SelectedValueChanged);
            // 
            // dgvPlayerStats
            // 
            this.dgvPlayerStats.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPlayerStats.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPlayerStats.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RC,
            this.Column1,
            this.GS,
            this.Ass});
            this.dgvPlayerStats.Location = new System.Drawing.Point(9, 375);
            this.dgvPlayerStats.Name = "dgvPlayerStats";
            this.dgvPlayerStats.Size = new System.Drawing.Size(444, 51);
            this.dgvPlayerStats.TabIndex = 17;
            // 
            // RC
            // 
            this.RC.HeaderText = "RC";
            this.RC.Name = "RC";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "YC";
            this.Column1.Name = "Column1";
            // 
            // GS
            // 
            this.GS.HeaderText = "GS";
            this.GS.Name = "GS";
            // 
            // Ass
            // 
            this.Ass.HeaderText = "Ass";
            this.Ass.Name = "Ass";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1267, 706);
            this.Controls.Add(this.cmbSelectFilter);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lblPlayerCount);
            this.Controls.Add(this.lblCurrent_Week);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainWindow";
            this.Text = "Fantasy Football Analyzer";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainWindow_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MainWindow_KeyPress);
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.MainWindow_PreviewKeyDown);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicturePlayer)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlayerStats)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblCurrent_Week;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getJsonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem downloafPhotosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem functionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewRAWDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.PictureBox PicturePlayer;
        private System.Windows.Forms.Label lblSecondName;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblPlayerCount;
        private System.Windows.Forms.Label lblChanceOfPlaying;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblTotalPoints;
        private System.Windows.Forms.Label lblValue;
        private System.Windows.Forms.Label lblPPPM;
        private System.Windows.Forms.Label lblPPG;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblGamesPlayed;
        private System.Windows.Forms.Label lblPPW;
        private System.Windows.Forms.Label lblAverageMinutes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cmbSelectFilter;
        private System.Windows.Forms.DataGridView dgvPlayerStats;
        private System.Windows.Forms.DataGridViewTextBoxColumn RC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn GS;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ass;
    }
}

